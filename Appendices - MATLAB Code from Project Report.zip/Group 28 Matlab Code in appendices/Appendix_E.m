%% 1) Define symbolic state and input variables
syms x y z u v w phi theta psi p q r real
syms omega1 omega2 omega3 omega4 real

X = [x; y; z; u; v; w; phi; theta; psi; p; q; r];
U = [omega1; omega2; omega3; omega4];

%% 2) Parameters & equilibrium
m   = 0.506;    g = 9.81;
I_x = 8.11858e-5; I_y = 8.11858e-5; I_z = 6.12223e-5;
l   = 0.235;    kF = 3.13e-5;    B = 0;

omega_hover = sqrt(m*g/(4*kF));
U_eq = repmat(omega_hover,4,1);
X_eq = zeros(12,1);

%% 3) Symbolic nonlinear dynamics f(X,U)
f = sym(zeros(12,1));
f(1:3) = [u; v; w];
T1 = kF*omega1^2; T2 = kF*omega2^2; T3 = kF*omega3^2; T4 = kF*omega4^2;
F = T1+T2+T3+T4;
f(4) = (F/m)*(cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi));
f(5) = (F/m)*(cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi));
f(6) = (F/m)*cos(phi)*cos(theta) - g;
f(7) = p + q*sin(phi)*tan(theta) + r*cos(phi)*tan(theta);
f(8) = q*cos(phi) - r*sin(phi);
f(9) = q*sin(phi)/cos(theta) + r*cos(phi)/cos(theta);
tau_phi   = l*(T4-T2);
tau_theta = l*(T3-T1);
tau_psi   = B*(-omega1^2+omega2^2-omega3^2+omega4^2);
f(10) = (tau_phi   - (I_y-I_z)*q*r)/I_x;
f(11) = (tau_theta - (I_z-I_x)*p*r)/I_y;
f(12) = (tau_psi   - (I_x-I_y)*p*q)/I_z;

%% 4) Jacobians
A_sym = jacobian(f, X);
B_sym = jacobian(f, U);

%% 5) Numeric linearization at hover
subsList = [X; U];
eqList   = [X_eq; U_eq];
A_lin = double(subs(A_sym, subsList, eqList));
B_lin = double(subs(B_sym, subsList, eqList));

disp('Linearized A at hover:'); disp(A_lin);
disp('Linearized B at hover:'); disp(B_lin);
save('linearModel.mat','A_lin','B_lin');

%% 6) Simulate the linear system ẋ = A_lin * x
tspan = [0 10];
IC = input('Enter 12×1 initial state [x y z u v w phi theta psi p q r]: ');
if numel(IC)~=12, error('Must supply 12‐element vector'); end
[T, X] = ode45(@(t,x) A_lin*x, tspan, IC(:));

%% 7) Plot the 12 states in a 3×4 grid
stateNames = {'x','y','z','u','v','w','\phi','\theta','\psi','p','q','r'};
yLabels = {'Position (m)','Position (m)','Position (m)', ...
           'Velocity (m/s)','Velocity (m/s)','Velocity (m/s)', ...
           'Angle (rad)','Angle (rad)','Angle (rad)', ...
           'Rate (rad/s)','Rate (rad/s)','Rate (rad/s)'};

figure('Name','Linear Hover Response','NumberTitle','off');
for i = 1:12
    subplot(3,4,i);
    plot(T, X(:,i), 'LineWidth',1.2);
    title(stateNames{i});
    xlabel('Time (s)');
    ylabel(yLabels{i});
    grid on; axis tight;
end