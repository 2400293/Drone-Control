%% Root Locus For Design of U1 

m = 0.506;
s = tf('s');

%% 1) P
figure;
G_P = 1/(m*s^2);        % plant
rlocus(G_P)             % loci of poles as K varies
title('Root Locus: P on 1/ms^2')
grid on

%% 2) PD

m = 0.506;
s = tf('s');


figure;
Ts_z     = 5;
zeta_z   = 0.5911;
omega_n_z= 4/(Ts_z*zeta_z);
P_z      = (2*zeta_z)/omega_n_z;

G_D = (1 + s*P_z)/(m*s^2);
rlocus(G_D)  
title('Root Locus: PD on 1/ms^2')
grid on

%% 3) PI

figure;
G_I = (s + P_z)/(m*s^3);
rlocus(G_I)
title('Root Locus: PI on 1/ms^2')
grid on
             
%% 4) PID
s = tf('s');
m = 0.506;        % [kg·m^2]

Ts_z     = 5;
zeta_z   = 0.5911;
omega_n_z= 4/(Ts_z*zeta_z);
P_z      = 5*omega_n_z;

figure;
G_PID =  (0.6611*s^2 + s + 0.9789)/(m*s^3);
rlocus(G_PID)  
title('Root Locus: PID on 1/(m s^2)')
grid on
