% loadQuadParams.m
% --------------------------------------------------
% Helper function to load quadcopter parameters

function params = loadQuadParams()
    params.m   = 0.506;
    params.g   = 9.81;
    params.I_x = 8.11858e-5;
    params.I_y = 8.11858e-5;
    params.I_z = 6.12223e-5;
    params.l   = 0.235;
    params.kF  = 3.13e-5;
    params.B   = 75e-7;
end
