

%% 1) Build the hover‐linearised state‐space model
m  = 0.506;               % mass [kg]
g  = 9.81;              % gravity [m/s^2]
Ix = 8.11858e-5;        % [kg·m^2]
Iy = 8.11858e-5;        % [kg·m^2]
Iz = 6.12223e-5;        % [kg·m^2]

A = zeros(12);APPENDIX_LINEAR_PID
A(1,4)=1;  A(2,5)=1;  A(3,6)=1;
A(4,8)= g; A(5,7)=-g;
A(7,10)=1; A(8,11)=1; A(9,12)=1;

B = zeros(12,4);
B(6,1)=1/m;   B(10,2)=1/Ix;
B(11,3)=1/Iy; B(12,4)=1/Iz;

C = zeros(4,12);
C(1,3)=1;  C(2,7)=1;
C(3,8)=1;  C(4,9)=1;
D = zeros(4,4);

drone_sys = ss(A, B, C, D);

%% 2) Define Laplace variable and derivative filter
s     = tf('s');
%% 3) PID GAINS

%% Z Gains

tau_d_z = 0.1;

Kpz     = 0.9263;
Ki_z    = 0;
Kdz     =  0.8094;

%% Phi Gains

tau_d_phi = 0.05;

Kp_phi   = 0.0009304;
Ki_phi    = 0;
Kd_phi     = 0.0003249;

%% Theta GAINS

tau_d_theta = 0.05;

Kp_theta   = 0.0009304;
Ki_theta   = 0;
Kd_theta    = 0.0003249;

%% Psi Gains

tau_d_psi = 0.05;

Kp_psi   = 0.0001121;        
Ki_psi   = 0;   
Kd_psi  = 0.0000979;



%% 4) CONTROLLERS: 

Cz     = Kpz + Ki_z/s    + (Kdz    * s)/(tau_d_z*s + 1);
Cphi   = Kp_phi + Ki_phi/s + (Kd_phi * s)/(tau_d_phi*s + 1);
Ctheta = Kp_theta + Ki_theta/s + (Kd_theta*s)/(tau_d_theta*s + 1);
Cpsi   = Kp_psi + Ki_psi/s + (Kd_psi * s)/(tau_d_psi*s + 1);



%% 5) Convert each to state‐space
Cz_ss     = ss(Cz);
Cphi_ss   = ss(Cphi);
Ctheta_ss = ss(Ctheta);
Cpsi_ss   = ss(Cpsi);


%% 6) Build block‐diagonal controller
C_all = blkdiag(Cz_ss, Cphi_ss, Ctheta_ss, Cpsi_ss);

%% 7) Close the full MIMO loop
drone_closed = feedback(drone_sys * C_all, eye(4));

%% 8) Simulate controlled performance

dt = 1e-4;                   % sampling period [s]
t  = 0:dt:5;                 % time vector


%% 9) SET INITIAL CONDITIONS
nx = size(drone_closed.A,1);
x0 = zeros(nx,1);
x0(1) = 0;                   % x
x0(2)= 0;                    % y
x0(3) = 0;                   % z
x0(4) = 0;                   % u
x0(5) = 0;                   % v
x0(6) = 0;                   % w
x0(7) = pi;                  % phi
x0(8) = 0;                   % theta
x0(9) = 0;                   % psi  
x0(10) = 0;                  % p
x0(11) = 0;                  % q
x0(12) = 0;                  % r

%% 10) step in thrust, zero torque commands
u = [ 1*ones(length(t),1), zeros(length(t),3) ];

[y, t_out, x] = lsim(drone_closed, u, t, x0);

%% 11) Plot all 12 states and the 4 controller outputs in subplots
% Compute the tracking error and actual controller outputs
% Compute the tracking error and actual controller outputs
e      = u - y;                        % error = reference – response
u_ctrl = lsim(C_all, e, t_out);       % controller’s output signals

figure('Name','States and Control Signals','Position',[200 200 1200 800]);

% Names for the 12 states
stateNames = {'x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r'};

% Plot the 12 states in a 4×4 grid (positions 1 to 12)
for i = 1:12
    subplot(4,4,i)
    plot(t_out, x_plot(:,i), 'LineWidth', 1.2)
    grid on
    title(stateNames{i})
    xlabel('Time [s]')
    ylabel(stateNames{i})
end

% Plot the 4 controller outputs (U₁–U₄) in the last row (positions 13 to 16)
for j = 1:4
    subplot(4,4,12 + j)
    plot(t_out, u_ctrl_plot(:,j), 'LineWidth', 1.2)
    grid on
    title(sprintf('Control Output U_{%d}', j))
    xlabel('Time [s]')
    ylabel(sprintf('U_{%d}', j))
end