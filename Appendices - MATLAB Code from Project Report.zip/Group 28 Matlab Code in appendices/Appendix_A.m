function simulateDroneLinear_UResponses_12States()
 
    % Computes Step, Ramp, and Sinusoid responses for a chosen input channel
    % on the 12-state linearized quadrotor model and plots each state on its
    % own subplot with the input overlaid in light grey.

    %% 1) Parameters & state-space matrices
    m  = 0.506;               
    g  = 9.81;                
    Ix = 8.11858e-5;          
    Iy = 8.11858e-5;          
    Iz = 6.12223e-5;          

    A = zeros(12);
    A(1,4)=1;   A(2,5)=1;   A(3,6)=1;
    A(4,8)= g;  A(5,7)=-g;
    A(7,10)=1;  A(8,11)=1;  A(9,12)=1;

    B = zeros(12,4);
    B(6,1)=1/m;
    B(10,2)=1/Ix;
    B(11,3)=1/Iy;
    B(12,4)=1/Iz;

    C = eye(12);    
    D = zeros(12,4);

    sys = ss(A, B, C, D);

    %% 2) Select which input channel to test and input amplitude
    inputChannel = 4;        % change to 1–4 as desired
    Ainp = 3.06115e-5;       % choose input size

    %% 3) Time vector
    tspan = 0:0.01:20; 

    %% 4) Define test signals

    tests = { ...
      struct('name','Step',     'u',@(t) Ainp*ones(size(t))), ...
      struct('name','Ramp',     'u',@(t) Ainp*t), ...
      struct('name','Sinusoid', 'u',@(t) Ainp*sin(2*pi*1*t)) ...
    };

    %% 5) Loop through each test, simulate, and plot
    
    for k = 1:numel(tests)
        test = tests{k};
        Uvec = test.u(tspan);
        U = zeros(length(tspan),4);
        U(:,inputChannel) = Uvec;

        % simulate linear response of all states
        [Y, T] = lsim(sys, U, tspan);

        % create figure
        figure('Name',[test.name ' Linear Response – U_' num2str(inputChannel)] , ...
               'NumberTitle','off');

        % plot all 12 states each on its own subplot
        stateNames = {'x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r'};
        for i = 1:12
            subplot(4,3,i)
            plot(T, Y(:,i), 'LineWidth',1.2); hold on
            plot(T, Uvec,   'Color',[0.8 0.8 0.8],'LineWidth',1);
            hold off
            grid on; axis square
            title([stateNames{i} ' Response'])
            xlabel('Time [s]')
            if i <= 3
                ylabel('Position [m]')
            elseif i <= 6
                ylabel('Velocity [m/s]')
            elseif i <= 9
                ylabel('Angle [rad]')
            else
                ylabel('Rate [rad/s]')
            end
            legend(stateNames{i},['U_' num2str(inputChannel) ' in'],'Location','best')
        end
    end
end