% NOTE: This code uses the function nyqlog. To run the code, download the
% function from MatLab directly. 

%% Define Variables:
s  = tf('s');

m  = 0.506;               % mass [kg]
Ix = 8.11858e-5;        % roll-axis inertia [kg·m^2]
Iy = 8.11858e-5;        % pitch-axis inertia [kg·m^2]
Iz = 6.12223e-5;        % yaw-axis inertia [kg·m^2]

K_p = 6.4016;
K_d = 4.2324;
K_i = 6.2663;

% Define Laplace variable
s = tf('s');

% Transfer functions
Gz     = 1/m*s^2;
Gx = 1/(Iy*s^4);
Gy = -1/(Ix*s^4);
Gpd = (K_p + K_d*s+K_i/s)/(m*s^2);

%% FOR TWO SIDE BY SIDE PLOTS

figure;

 % Left plot
subplot(1,2,1);
nyquist(Gpd);
grid on;
title('Nyquist plot of PID controlled Open Loop');
%ylim(1e-3*[-1 1]);                          % Add for pure integrator plots
%xlim([-5 1]);
xlabel('Re.');
ylabel('Im.');

 % Right plot
subplot(1,2,2);
nyqlog(Gpd);
grid on;
title('Log Nyquist plot of PID controlled Open Loop');
xlabel('Re.');
ylabel('Im.');

%% FOR A SINGLE PLOT 

%figure;
%    nyquist(Gpd);
%   grid on;
%   title('Nyquist plot');
%    xlabel('Re');
%    ylabel('Im');