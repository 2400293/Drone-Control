%% Simulate Non Linear Drone

params.m    = 0.506;    % mass [kg]
params.g    = 9.81;     % gravitational acceleration [m/s^2]
params.I_x  = 8.11858e-5;   % moment of inertia about x-axis [kg·m^2]
params.I_y  = 8.11858e-5;   % moment of inertia about y-axis [kg·m^2]
params.I_z  = 6.12223e-5;   % moment of inertia about z-axis [kg·m^2]
params.l    = 0.235;        % two times arm length [m]

%% Rotor constants:
params.kF   = 3.13e-5;   % Lift constant [N/(rad/s)^2]
params.B    = 75e-7*0;   % Drag constant [N·m/(rad/s)^2]

%% Compute ideal rotor speed for hover
omega_hover = sqrt(params.m*params.g/(4*params.kF));
params.omega = repmat(omega_hover,4,1);

%% Initial condition: ['x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r']
x0 = zeros(12,1);
x0(1) = 1;
      x0(1) = 1;
    x0(2) = 1;
    x0(3) = 1;
    x0(4) = 0;
    x0(5) = 0;
    x0(6) = 0;
    x0(7) = 0;
    x0(8) = 0;
    x0(9) = 30*pi/180;
    x0(10) = 0;
    x0(11) = 0;
    x0(12) = 0;
%% Time span
tspan = [0 20];

%% Simulate open-loop hover
[t, X] = ode45(@(t,x) quadNonlinearDynamics(t, x, params), tspan, x0);

%% Plot all 12 states in a 4x3 grid
stateNames = {'x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r'};
yLabels    = {'Position (m)','Position (m)','Position (m)', ...
              'Velocity (m/s)','Velocity (m/s)','Velocity (m/s)', ...
              'Angle (rad)','Angle (rad)','Angle (rad)', ...
              'Rate (rad/s)','Rate (rad/s)','Rate (rad/s)'};

figure('Name','Hover Response: 12 States','NumberTitle','off');
for i = 1:12
    subplot(4,3,i)
    if i>=7 && i<=9
        % Euler angles: plot in radians
        plot(t, X(:,i), 'LineWidth',1.2);
    else
        plot(t, X(:,i), 'LineWidth',1.2);
    end
    title(stateNames{i});
    xlabel('Time (s)');
    ylabel(yLabels{i});
    grid on
    axis tight
end