function hoverMMAControlXYPID()
    % hoverMMAControlXYPID – Full PID+MMA hover control following a waypoint path
    %
    % The quadrotor will hover at 0,0,0 then follow:
    %   [1,1,1] → [1,2,1] → [1,3,1] → [2,3,1] → [2,2,1] → [2,1,1],
    % holding each waypoint for 5 s.

    %% 1) Load params & hover speed
    params      = loadQuadParams();
    kF          = params.kF;
    l           = params.l;
    B           = params.B;
    m           = params.m;
    g           = params.g;
    omega_hover = sqrt(m * g / (4*kF));

    %% 2) PID gains
    Kp_z     =  8.6;   Ki_z     = 8;    Kd_z     = 5.16;    % altitude U1
    Kp_phi   = 0.009;  Ki_phi   =0.0003;    Kd_phi   =0.001;   % roll     U2
    Kp_theta = 0.009;  Ki_theta =0.0003;    Kd_theta =0.001;   % pitch    U3
    Kp_psi   = 0.003;  Ki_psi   =0.0004;    Kd_psi   =1.8e-3; % yaw      U4

    Kp_x   = 5;  Ki_x   = 2;  Kd_x   = 3.8;  % outer x
    Kp_y   = Kp_x;  Ki_y   = Ki_x;  Kd_y   = Kd_x;  % outer y

    %% 3) Precompute mixer inverse
    M = [  kF,     kF,     kF,    kF;
           0,  -kF*l,      0,  kF*l;
        -kF*l,     0,   kF*l,      0;
          -B,      B,     -B,      B ];
    Minv = inv(M);

    %% 4) Define waypoints and timing
    waypts = [ 0 0 0;
               1 1 1;
               1 2 1;
               1 3 1;
               2 3 1;
               2 2 1;
               2 1 1;
               2 0 1;
               2 0 1;
               1 0 0;
               0 0 0;
               0 0 0];

    holdTime = 10;                                    % seconds per waypoint
    t_ref    = (0:size(waypts,1)-1) * holdTime;      % [0,5,10,...,30]
    totalT   = t_ref(end);
    tspan    = [0 totalT];

    %% 5) Initial conditions
    x0       = zeros(12,1);
    x0(1:3)  = waypts(1,:)';    % start at [0;0;0]
    x0(7:9)  = [0;0;0];         % zero attitudes
    I0       = zeros(6,1);
    X0_ext   = [x0; I0];

    %% 6) Simulate over full trajectory
    odefun = @(t,X) combinedDynXYPID( ...
        t, X, params, omega_hover, Minv, ...
        Kp_z,Ki_z,Kd_z, ...
        Kp_phi,Ki_phi,Kd_phi, ...
        Kp_theta,Ki_theta,Kd_theta, ...
        Kp_psi,Ki_psi,Kd_psi, ...
        Kp_x,Ki_x,Kd_x, ...
        Kp_y,Ki_y,Kd_y, ...
        interp1(t_ref, waypts(:,1), t, 'previous'), ...
        interp1(t_ref, waypts(:,2), t, 'previous'), ...
        interp1(t_ref, waypts(:,3), t, 'previous'), ...
        0, g);

    [t, Xext] = ode45(odefun, tspan, X0_ext);

    %% 7) Plot physical states
    X = Xext(:,1:12);

    figure;
    subplot(2,1,1);
    plot(t, X(:,1:3), 'LineWidth',1.2);
    legend('x','y','z');
    title('Position under PID+MMA Control');
    xlabel('Time (s)'); ylabel('m'); grid on;

    subplot(2,1,2);
    plot(t, rad2deg(X(:,7:9)), 'LineWidth',1.2);
    legend('\phi','\theta','\psi');
    title('Attitude under PID+MMA Control');
    xlabel('Time (s)'); ylabel('deg'); grid on;

    % 3D trajectory
    x_traj = X(:,1); y_traj = X(:,2); z_traj = X(:,3);
    figure;
    plot3(x_traj, y_traj, z_traj, 'LineWidth',1.5);
    grid on; axis equal;
    xlabel('x (m)'); ylabel('y (m)'); zlabel('z (m)');
    title('3D Trajectory of the Quadcopter');
    view(45,25);
    hold on;
    plot3(x_traj(1), y_traj(1), z_traj(1), 'go', 'MarkerSize',10, 'DisplayName','Start');
    plot3(x_traj(end), y_traj(end), z_traj(end), 'r^', 'MarkerSize',10, 'DisplayName','End');
    legend('Trajectory','Start','End');
end

function dXext = combinedDynXYPID(t, Xext, params, omega_hover, Minv, ...
                                  Kp_z,Ki_z,Kd_z, ...
                                  Kp_phi,Ki_phi,Kd_phi, ...
                                  Kp_theta,Ki_theta,Kd_theta, ...
                                  Kp_psi,Ki_psi,Kd_psi, ...
                                  Kp_x,Ki_x,Kd_x, ...
                                  Kp_y,Ki_y,Kd_y, ...
                                  x_ref,y_ref, z_ref, psi_ref, g)
    % Split extended state
    xstate = Xext(1:12);
    iz     = Xext(13); ip = Xext(14); it = Xext(15);
    ips    = Xext(16); ix = Xext(17); iy = Xext(18);

    dt = 0.01;  % PID update interval

    % Unpack vehicle state
    x     = xstate(1);  u = xstate(4);
    y     = xstate(2);  v = xstate(5);
    z     = xstate(3);  w = xstate(6);
    phi   = xstate(7);  p = xstate(10);
    theta = xstate(8);  q = xstate(11);
    psi   = xstate(9);  r = xstate(12);

    %% Outer loops → attitude refs
    ex       = x_ref - x;    ix = ix + ex*dt;    dex = -u;
    Ux       = Kp_x*ex + Ki_x*ix + Kd_x*dex;
    theta_ref= Ux / g;

    ey       = y_ref - y;    iy = iy + ey*dt;    dey = -v;
    Uy       = Kp_y*ey + Ki_y*iy + Kd_y*dey;
    phi_ref  = -Uy / g;

    %% Inner loops → U1…U4
    ez    = z_ref - z;    iz = iz + ez*dt;    dez = -w;
    U1    = Kp_z*ez + Ki_z*iz + Kd_z*dez;

    e_phi = phi_ref - phi;    ip = ip + e_phi*dt;    dep = -p;
    U2    = Kp_phi*e_phi + Ki_phi*ip + Kd_phi*dep;

    e_th  = theta_ref - theta;    it = it + e_th*dt;    det = -q;
    U3    = Kp_theta*e_th + Ki_theta*it + Kd_theta*det;

    e_ps  = psi_ref - psi;    ips = ips + e_ps*dt;    deps = -r;
    U4    = Kp_psi*e_ps + Ki_psi*ips + Kd_psi*deps;

    %% Motor Mixing
    U    = [U1;U2;U3;U4];
    f    = Minv * U;   f = max(f, 0);
    params.omega = sqrt(f);

    % Compute dynamics
    dx        = quadNonlinearDynamics(t, xstate, params);

    % Integrator derivatives
    diz  = ez;  dip  = e_phi;  dit  = e_th;
    dips = e_ps; dix  = ex;     diy  = ey;

    % Pack extended derivative
    dXext = [dx; diz; dip; dit; dips; dix; diy];
end