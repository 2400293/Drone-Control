function NON_LINEAR_NOXY_12STATES()
    
    % NOTE:
    % Make sure quadNonlinearDynamics.m and loadQuadParams.m are on your path


    %% 1) Load parameters & hover speed
    params      = loadQuadParams();
    kF          = params.kF;
    l           = params.l;
    B           = params.B;
    m           = params.m;
    g           = params.g;
    omega_hover = sqrt(m*g/(4*kF));

    %% 2) PID gains 
    Kp_z     =  6.4016 ;  Ki_z     = 6.2663;  Kd_z   = 4.2324;
    Kp_phi   = 0.0064;  Ki_phi   =  0.0157 ;  Kd_phi = 0.0017;
    Kp_theta = 0.0064;  Ki_theta =  0.0157 ;  Kd_theta = 0.0017;
    Kp_psi   = 0.0048;  Ki_psi   = 0.0119;  Kd_psi = 0.0013;

    %% 3) References
    z_ref     = 1.0;    % [m]
    phi_ref   = 0.0;    % [rad]
    theta_ref = 0.0;    % [rad]
    psi_ref   = 0.0;    % [rad]

    %% 4) Precompute mixer inverse
    M = [  kF,     kF,     kF,    kF;
           0,  -kF*l,      0,  kF*l;
        -kF*l,     0,   kF*l,      0;
          -B,      B,     -B,      B ];
    Minv = inv(M);

    %% 5) Initial condition (12 states + 4 integrators)
    x0       = zeros(12,1);

x0 = zeros(12,1);
x0(1) = 0;                   % x
x0(2)= 0;                    % y
x0(3) = 0;                   % z
x0(4) = 0;                   % u
x0(5) = 0;                   % v
x0(6) = 0;                   % w
x0(7) = pi;                  % phi
x0(8) = 0;                   % theta
x0(9) = 0;                   % psi  
x0(10) = 0;                  % p
x0(11) = 0;                  % q
x0(12) = 0;                  % r

    I0       = zeros(4,1);        % initial integrals [iz; ip; it; ips]
    X0_ext   = [x0; I0];

    %% 6) Simulate
    tspan = [0 8];
    [t, Xext] = ode45(@(t, X) combinedDynExt(...
        t, X, params, omega_hover, Minv, ...
        Kp_z,Ki_z,Kd_z, ...
        Kp_phi,Ki_phi,Kd_phi, ...
        Kp_theta,Ki_theta,Kd_theta, ...
        Kp_psi,Ki_psi,Kd_psi, ...
        z_ref,phi_ref,theta_ref,psi_ref), ...
        tspan, X0_ext);

    %% 7) Extract states and recompute inputs
    X = Xext(:,1:12);
    U = zeros(length(t),4);
    iz=0; ip=0; it=0; ips=0;
    dt = t(2)-t(1);
    for k=1:length(t)
        xs = X(k,:)';
        z    = xs(3); w    = xs(6);
        phi  = xs(7); p    = xs(10);
        theta= xs(8); q    = xs(11);
        psi  = xs(9); r    = xs(12);
        % Altitude
        ez = z_ref - z; iz = iz + ez*dt; dez = -w;
        U1 = Kp_z*ez + Ki_z*iz + Kd_z*dez;
        % Roll
        e_phi = phi_ref - phi; ip = ip + e_phi*dt; dep = -p;
        U2 = Kp_phi*e_phi + Ki_phi*ip + Kd_phi*dep;
        % Pitch
        e_th = theta_ref - theta; it = it + e_th*dt; det = -q;
        U3 = Kp_theta*e_th + Ki_theta*it + Kd_theta*det;
        % Yaw
        e_ps = psi_ref - psi; ips = ips + e_ps*dt; deps = -r;
        U4 = Kp_psi*e_ps + Ki_psi*ips + Kd_psi*deps;
        U(k,:) = [U1 U2 U3 U4];
    end

    %% 8) Plot each state and input in a 4x4 grid
    figure;
    stateNames = {'x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r'};
    for i=1:12
        subplot(4,4,i);
        plot(t, X(:,i), 'LineWidth',1.2);
        ylabel(stateNames{i});
        title(stateNames{i});
        if i>8 || mod(i,4)==1, xlabel('Time (s)'); end
        grid on;
    end
    inputNames = {'U1 (thrust)','U2 (roll)','U3 (pitch)','U4 (yaw)'};
    for j=1:4
        subplot(4,4,12+j);
        plot(t, U(:,j), 'LineWidth',1.2);
        ylabel(inputNames{j}); xlabel('Time (s)'); grid on;
        title(inputNames{j});
    end
end

function dXext = combinedDynExt(t, Xext, params, omega_hover, Minv, ...
                                Kp_z,Ki_z,Kd_z, ...
                                Kp_phi,Ki_phi,Kd_phi, ...
                                Kp_theta,Ki_theta,Kd_theta, ...
                                Kp_psi,Ki_psi,Kd_psi, ...
                                z_ref,phi_ref,theta_ref,psi_ref)
    x     = Xext(1:12);
    iz    = Xext(13); ip    = Xext(14);
    it    = Xext(15); ips   = Xext(16);
    dt = 0.01;
    z     = x(3); w     = x(6);
    phi   = x(7); p     = x(10);
    theta = x(8); q     = x(11);
    psi   = x(9); r     = x(12);
    % PID computations
    ez  = z_ref - z;    iz  = iz + ez*dt; dez  = -w;    U1  = Kp_z*ez + Ki_z*iz + Kd_z*dez;
    e_phi = phi_ref - phi; ip = ip + e_phi*dt; dep = -p; U2 = Kp_phi*e_phi + Ki_phi*ip + Kd_phi*dep;
    e_th  = theta_ref - theta; it = it + e_th*dt; det = -q; U3 = Kp_theta*e_th + Ki_theta*it + Kd_theta*det;
    e_ps  = psi_ref - psi; ips = ips + e_ps*dt; deps = -r; U4 = Kp_psi*e_ps + Ki_psi*ips + Kd_psi*deps;
    U  = [U1;U2;U3;U4]; f = Minv*U; f = max(f,0); omega = sqrt(f);
    params.omega = omega;
    dx = quadNonlinearDynamics(t, x, params);
    dXext = [dx; ez; e_phi; e_th; e_ps];
end