function simulateDroneNonlinear_UResponses_12States()
    %% 1) Load vehicle parameters and compute mixer inverse
    params      = loadQuadParams();
    kF          = params.kF;
    l           = params.l;
    B           = params.B;
    m           = params.m;
    g           = params.g;

    M = [  kF,     kF,     kF,    kF;
           0,  -kF*l,      0,  kF*l;
        -kF*l,     0,   kF*l,      0;
          -B,      B,     -B,      B ];
    Minv = inv(M);

    %% 2) Select which input channel to test
    inputChannel = 4;        % change to 1–4 as desired
    A = 5*1.624e-6;          % choose input size

    %% 3) Initial state and time vector
    x0    = zeros(12,1);            % [x;y;z;u;v;w;phi;theta;psi;p;q;r]
    tspan = 0:0.01:20;              % 0–5 s

    %% 4) Define test signals
    
    tests = { ...
      struct('name','Step',     'u',@(t) A*ones(size(t))), ...
      struct('name','Ramp',     'u',@(t) A*t), ...
      struct('name','Sinusoid', 'u',@(t) A*sin(2*pi*1*t)) ...
    };

    %% 5) Loop through each test, simulate, and plot
    for k = 1:numel(tests)
        test = tests{k};
        Uvec = test.u(tspan);

        % simulate open-loop nonlinear dynamics
        [T, X] = ode45(@(t,x) nlDyn(t, x, test.u), tspan, x0);

        % create figure
        figure('Name',[test.name ' Non-Linear Response – U_' num2str(inputChannel)], ...
               'NumberTitle','off');

        % plot all 12 states each on its own subplot
        stateNames = {'x','y','z','ẋ','ẏ','ż','φ','θ','ψ','p','q','r'};
        for i = 1:12
            subplot(4,3,i)
            plot(T, X(:,i), 'LineWidth',1.2); hold on
            plot(T, Uvec,  'Color',[0.8 0.8 0.8],'LineWidth',1);
            hold off
            grid on; axis square
            title([stateNames{i} ' Response'])
            xlabel('Time [s]')
            if i <= 3
                ylabel('Position [m]')
            elseif i <= 6
                ylabel('Velocity [m/s]')
            elseif i <= 9
                ylabel('Angle [rad]')
            else
                ylabel('Rate [rad/s]')
            end
            legend(stateNames{i},['U_' num2str(inputChannel) ' in'],'Location','best')
        end
    end

    %% Nested dynamics function
    function dx = nlDyn(t, x, uFcn)
        % baseline hover thrust to cancel weight
        U = [m*g; 0; 0; 0];
        % add test signal on selected channel
        u = uFcn(t);
        U(inputChannel) = U(inputChannel) + u;
        % mixer → rotor speeds
        f           = Minv * U;
        params.omega = sqrt(max(f,0));
        % compute state derivatives
        dx = quadNonlinearDynamics(t, x, params);
    end
end